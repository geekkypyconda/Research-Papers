package s;

import android.content.Context;
import java.util.concurrent.Executor;
import r.j;

public interface a {
   void a(Context var1, Executor var2, h.a<j> var3);

   void b(h.a<j> var1);
}
