package a1;

import java.io.Serializable;

public final class q<T> implements Serializable {
   public T e;

   public String toString() {
      return String.valueOf(this.e);
   }
}
