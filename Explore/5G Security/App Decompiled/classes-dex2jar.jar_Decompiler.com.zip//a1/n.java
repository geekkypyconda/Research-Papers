package a1;

public abstract class n extends p implements e1.f {
   public n(Object var1, Class var2, String var3, String var4, int var5) {
      super(var1, var2, var3, var4, var5);
   }

   public Object b() {
      return this.get();
   }

   protected e1.a c() {
      return r.d(this);
   }
}
