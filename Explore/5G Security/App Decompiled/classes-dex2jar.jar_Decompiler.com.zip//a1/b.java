package a1;

import java.util.Iterator;

public final class b {
   public static final <T> Iterator<T> a(T[] var0) {
      k.e(var0, "array");
      return new a(var0);
   }
}
