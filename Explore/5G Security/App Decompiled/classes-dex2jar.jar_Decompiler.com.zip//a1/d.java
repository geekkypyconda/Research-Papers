package a1;

public interface d extends e1.d {
   Class<?> c();
}
