package a1;

public interface h<R> extends p0.c<R> {
   int e();
}
