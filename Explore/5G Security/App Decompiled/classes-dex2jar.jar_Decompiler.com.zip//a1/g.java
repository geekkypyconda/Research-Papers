package a1;

public final class g {
}
