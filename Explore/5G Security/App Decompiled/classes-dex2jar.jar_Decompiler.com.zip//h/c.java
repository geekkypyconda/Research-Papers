package h;

public final class c {
   public static <T> T a(T var0) {
      var0.getClass();
      return var0;
   }
}
