package h;

import java.util.Objects;

public class b {
   public static boolean a(Object var0, Object var1) {
      return Objects.equals(var0, var1);
   }

   public static int b(Object... var0) {
      return Objects.hash(var0);
   }
}
