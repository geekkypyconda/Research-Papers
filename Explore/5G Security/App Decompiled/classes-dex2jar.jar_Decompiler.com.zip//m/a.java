package m;

public interface a {
}
