package e1;

public interface d {
}
