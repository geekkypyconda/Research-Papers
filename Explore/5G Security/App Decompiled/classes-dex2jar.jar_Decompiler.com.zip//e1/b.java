package e1;

public interface b<T> extends d {
   String a();

   String b();

   boolean d(Object var1);
}
