package e1;

public interface f<V> extends g<V>, z0.a<V> {
   V get();
}
