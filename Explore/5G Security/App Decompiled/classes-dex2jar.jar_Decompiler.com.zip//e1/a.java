package e1;

public interface a<R> {
}
