package e1;

public interface e<R> extends a<R>, p0.c<R> {
}
