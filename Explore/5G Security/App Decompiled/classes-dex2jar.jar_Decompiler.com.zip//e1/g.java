package e1;

public interface g<V> extends a<V> {
}
