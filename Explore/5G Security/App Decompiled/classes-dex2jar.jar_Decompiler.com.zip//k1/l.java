package k1;

import m1.h0;

public final class l {
   public static final h0 a = new h0("NO_VALUE");

   public static final <T> c<T> a(k<? extends T> var0, r0.g var1, int var2, j1.a var3) {
      return (c)((var2 == 0 || var2 == -3) && var3 == j1.a.e ? var0 : new l1.g(var0, var1, var2, var3));
   }
}
