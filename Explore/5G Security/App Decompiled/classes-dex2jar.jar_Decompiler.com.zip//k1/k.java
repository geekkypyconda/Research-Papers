package k1;

public interface k<T> extends c<T> {
}
