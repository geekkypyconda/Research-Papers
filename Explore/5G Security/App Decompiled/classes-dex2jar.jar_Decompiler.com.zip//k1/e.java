package k1;

import j1.t;

public final class e {
   public static final <T> c<T> a(z0.p<? super j1.r<? super T>, ? super r0.d<? super p0.q>, ? extends Object> var0) {
      return f.a(var0);
   }

   public static final <T> Object b(d<? super T> var0, t<? extends T> var1, r0.d<? super p0.q> var2) {
      return g.b(var0, var1, var2);
   }

   public static final void c(d<?> var0) {
      i.a(var0);
   }

   public static final <T> c<T> d(c<? extends T> var0, r0.g var1) {
      return h.b(var0, var1);
   }
}
