package k1;

// $FF: synthetic class
final class i {
   public static final void a(d<?> var0) {
      if (var0 instanceof r) {
         throw ((r)var0).e;
      }
   }
}
