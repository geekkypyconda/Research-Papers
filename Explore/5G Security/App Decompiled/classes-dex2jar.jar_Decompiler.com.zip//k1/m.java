package k1;

public interface m<T> extends k<T> {
}
