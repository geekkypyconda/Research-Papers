package k1;

public interface d<T> {
   Object c(T var1, r0.d<? super p0.q> var2);
}
