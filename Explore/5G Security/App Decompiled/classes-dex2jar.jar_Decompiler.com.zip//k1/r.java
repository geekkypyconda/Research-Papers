package k1;

public final class r implements d<Object> {
   public final Throwable e;

   public Object c(Object var1, r0.d<? super p0.q> var2) {
      throw this.e;
   }
}
