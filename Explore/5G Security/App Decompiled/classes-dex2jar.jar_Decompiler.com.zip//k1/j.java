package k1;

public interface j<T> extends m<T>, k, d {
   void setValue(T var1);
}
