package k1;

// $FF: synthetic class
final class f {
   public static final <T> c<T> a(z0.p<? super j1.r<? super T>, ? super r0.d<? super p0.q>, ? extends Object> var0) {
      return new a(var0, (r0.g)null, 0, (j1.a)null, 14, (a1.g)null);
   }
}
