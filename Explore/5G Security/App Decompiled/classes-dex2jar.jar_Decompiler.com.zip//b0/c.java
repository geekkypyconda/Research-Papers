package b0;

// $FF: synthetic class
public final class c implements Runnable {
   // $FF: synthetic field
   public final <undefinedtype> e;

   // $FF: synthetic method
   public c(Object var1) {
      this.e = var1;
   }

   public final void run() {
      null.a(this.e);
   }
}
