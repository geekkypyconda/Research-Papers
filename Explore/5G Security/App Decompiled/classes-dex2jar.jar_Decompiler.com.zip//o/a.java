package o;

import android.util.Log;

public final class a implements g {
   public static final a a = new a();

   private a() {
   }

   public void a(String var1, String var2) {
      a1.k.e(var1, "tag");
      a1.k.e(var2, "message");
      Log.d(var1, var2);
   }
}
