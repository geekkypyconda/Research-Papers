package o;

public final class c {
   public static final c a = new c();
   private static final j b;

   static {
      b = j.g;
   }

   private c() {
   }

   public final j a() {
      return b;
   }
}
