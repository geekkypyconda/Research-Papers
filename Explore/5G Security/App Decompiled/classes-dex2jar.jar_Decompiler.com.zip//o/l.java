package o;

public final class l extends Exception {
   public l(String var1) {
      a1.k.e(var1, "message");
      super(var1);
   }
}
