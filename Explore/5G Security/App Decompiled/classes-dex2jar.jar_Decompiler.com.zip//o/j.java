package o;

public enum j {
   e,
   f,
   g;

   // $FF: synthetic method
   private static final j[] a() {
      return new j[]{e, f, g};
   }
}
