package o;

public interface g {
   void a(String var1, String var2);
}
