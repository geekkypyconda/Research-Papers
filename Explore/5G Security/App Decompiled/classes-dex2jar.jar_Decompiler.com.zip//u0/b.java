package u0;

public final class b {
   public static final a a;

   static {
      // $FF: Couldn't be decompiled
   }
}
