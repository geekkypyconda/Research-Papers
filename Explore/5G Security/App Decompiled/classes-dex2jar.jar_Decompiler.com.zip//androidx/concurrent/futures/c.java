package androidx.concurrent.futures;

public final class c<V> extends a<V> {
   private c() {
   }

   public static <V> androidx.concurrent.futures.c<V> q() {
      return new androidx.concurrent.futures.c();
   }

   public boolean o(V var1) {
      return super.o(var1);
   }
}
