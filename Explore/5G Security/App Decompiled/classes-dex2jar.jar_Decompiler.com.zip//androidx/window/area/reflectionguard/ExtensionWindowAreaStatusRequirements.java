package androidx.window.area.reflectionguard;

import android.util.DisplayMetrics;

public interface ExtensionWindowAreaStatusRequirements {
   DisplayMetrics getWindowAreaDisplayMetrics();

   int getWindowAreaStatus();
}
