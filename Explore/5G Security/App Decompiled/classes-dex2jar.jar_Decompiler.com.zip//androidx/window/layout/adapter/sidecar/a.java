package androidx.window.layout.adapter.sidecar;

import android.app.Activity;
import r.j;

public interface a {
   void a(androidx.window.layout.adapter.sidecar.a.a var1);

   void b(Activity var1);

   void c(Activity var1);

   public interface a {
      void a(Activity var1, j var2);
   }
}
