package androidx.window.extensions.core.util.function;

@FunctionalInterface
public interface Consumer<T> {
   void accept(T var1);
}
