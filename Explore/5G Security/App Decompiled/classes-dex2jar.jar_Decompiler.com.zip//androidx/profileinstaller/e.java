package androidx.profileinstaller;

import java.util.TreeMap;

class e {
   final String a;
   final String b;
   final long c;
   long d;
   int e;
   final int f;
   final int g;
   int[] h;
   final TreeMap<Integer, Integer> i;

   e(String var1, String var2, long var3, long var5, int var7, int var8, int var9, int[] var10, TreeMap<Integer, Integer> var11) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var5;
      this.e = var7;
      this.f = var8;
      this.g = var9;
      this.h = var10;
      this.i = var11;
   }
}
