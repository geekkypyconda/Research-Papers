package androidx.profileinstaller;

class r {
   final g a;
   final int b;
   final byte[] c;
   final boolean d;

   r(g var1, int var2, byte[] var3, boolean var4) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
   }
}
