package androidx.profileinstaller;

// $FF: synthetic class
public final class b {
}
