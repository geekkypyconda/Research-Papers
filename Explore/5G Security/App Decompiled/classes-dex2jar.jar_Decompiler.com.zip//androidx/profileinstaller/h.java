package androidx.profileinstaller;

import java.util.concurrent.Executor;

// $FF: synthetic class
public final class h implements Executor {
   public final void execute(Runnable var1) {
      var1.run();
   }
}
