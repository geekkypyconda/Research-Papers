package androidx.profileinstaller;

// $FF: synthetic class
public final class c implements Runnable {
   // $FF: synthetic field
   public final d e;
   // $FF: synthetic field
   public final int f;
   // $FF: synthetic field
   public final Object g;

   // $FF: synthetic method
   public c(d var1, int var2, Object var3) {
      this.e = var1;
      this.f = var2;
      this.g = var3;
   }

   public final void run() {
      d.a(this.e, this.f, this.g);
   }
}
