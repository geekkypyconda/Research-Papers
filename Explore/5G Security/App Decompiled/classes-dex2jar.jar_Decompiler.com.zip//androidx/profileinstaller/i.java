package androidx.profileinstaller;

// $FF: synthetic class
public final class i implements Runnable {
   // $FF: synthetic field
   public final j.c e;
   // $FF: synthetic field
   public final int f;
   // $FF: synthetic field
   public final Object g;

   // $FF: synthetic method
   public i(j.c var1, int var2, Object var3) {
      this.e = var1;
      this.f = var2;
      this.g = var3;
   }

   public final void run() {
      j.a(this.e, this.f, this.g);
   }
}
