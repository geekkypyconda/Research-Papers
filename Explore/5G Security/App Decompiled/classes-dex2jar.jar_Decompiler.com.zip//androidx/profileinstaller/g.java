package androidx.profileinstaller;

enum g {
   f(0L),
   g(1L),
   h(2L),
   i(3L),
   j(4L);

   private final long e;

   private g(long var3) {
      this.e = var3;
   }

   // $FF: synthetic method
   private static g[] a() {
      return new g[]{f, g, h, i, j};
   }

   public long b() {
      return this.e;
   }
}
