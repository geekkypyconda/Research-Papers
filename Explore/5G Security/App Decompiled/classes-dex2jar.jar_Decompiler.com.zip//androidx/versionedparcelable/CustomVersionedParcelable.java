package androidx.versionedparcelable;

public abstract class CustomVersionedParcelable implements m.a {
}
