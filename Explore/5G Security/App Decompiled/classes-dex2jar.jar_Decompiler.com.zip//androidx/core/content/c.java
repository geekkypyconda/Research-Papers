package androidx.core.content;

import android.content.res.Configuration;

public interface c {
   void a(h.a<Configuration> var1);

   void b(h.a<Configuration> var1);
}
