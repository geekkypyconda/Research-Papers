package androidx.core.content;

// $FF: synthetic class
public final class a {
}
