package androidx.core.view;

// $FF: synthetic class
public final class t {
}
