package androidx.core.view;

import android.view.View;

public interface b {
   v a(View var1, v var2);
}
