package androidx.core.graphics.drawable;

// $FF: synthetic class
public final class c {
}
