package androidx.lifecycle;

public interface g {
   void a(l var1, h.a var2, boolean var3, p var4);
}
