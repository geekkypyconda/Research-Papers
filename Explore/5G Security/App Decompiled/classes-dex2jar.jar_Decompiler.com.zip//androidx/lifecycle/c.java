package androidx.lifecycle;

// $FF: synthetic class
public final class c {
   public static void a(d var0, l var1) {
      a1.k.e(var1, "owner");
   }

   public static void b(d var0, l var1) {
      a1.k.e(var1, "owner");
   }

   public static void c(d var0, l var1) {
      a1.k.e(var1, "owner");
   }

   public static void d(d var0, l var1) {
      a1.k.e(var1, "owner");
   }

   public static void e(d var0, l var1) {
      a1.k.e(var1, "owner");
   }
}
