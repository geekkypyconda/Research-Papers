package androidx.lifecycle;

public interface l {
   h b();
}
