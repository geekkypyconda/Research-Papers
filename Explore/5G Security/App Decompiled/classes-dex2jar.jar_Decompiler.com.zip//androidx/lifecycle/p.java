package androidx.lifecycle;

import java.util.HashMap;
import java.util.Map;

public class p {
   private final Map<String, Integer> a = new HashMap();
}
