package androidx.lifecycle;

@Deprecated
class u implements j {
   private final Object a;
   private final a.a b;

   u(Object var1) {
      this.a = var1;
      this.b = androidx.lifecycle.a.c.c(var1.getClass());
   }

   public void d(l var1, h.a var2) {
      this.b.a(var1, var2, this.a);
   }
}
