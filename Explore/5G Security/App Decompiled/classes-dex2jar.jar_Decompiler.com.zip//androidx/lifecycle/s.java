package androidx.lifecycle;

// $FF: synthetic class
public final class s {
}
