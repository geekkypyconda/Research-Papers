package androidx.lifecycle;

public interface d extends k {
   void a(l var1);

   void b(l var1);

   void c(l var1);

   void e(l var1);

   void f(l var1);

   void g(l var1);
}
