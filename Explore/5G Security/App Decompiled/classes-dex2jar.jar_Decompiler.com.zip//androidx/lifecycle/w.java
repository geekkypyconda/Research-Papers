package androidx.lifecycle;

public final class w implements j {
   private final g a;

   public w(g var1) {
      a1.k.e(var1, "generatedAdapter");
      super();
      this.a = var1;
   }

   public void d(l var1, h.a var2) {
      a1.k.e(var1, "source");
      a1.k.e(var2, "event");
      this.a.a(var1, var2, false, (p)null);
      this.a.a(var1, var2, true, (p)null);
   }
}
