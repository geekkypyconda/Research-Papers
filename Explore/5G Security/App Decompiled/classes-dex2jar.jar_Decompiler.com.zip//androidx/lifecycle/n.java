package androidx.lifecycle;

@Deprecated
public interface n extends l {
   m b();
}
