package androidx.lifecycle;

public interface j extends k {
   void d(l var1, h.a var2);
}
