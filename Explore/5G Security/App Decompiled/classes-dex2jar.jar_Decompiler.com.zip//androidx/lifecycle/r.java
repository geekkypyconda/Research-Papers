package androidx.lifecycle;

// $FF: synthetic class
public final class r implements Runnable {
   // $FF: synthetic field
   public final t e;

   // $FF: synthetic method
   public r(t var1) {
      this.e = var1;
   }

   public final void run() {
      t.a(this.e);
   }
}
