package o0;

public interface e<T> {
   boolean test(T var1);
}
