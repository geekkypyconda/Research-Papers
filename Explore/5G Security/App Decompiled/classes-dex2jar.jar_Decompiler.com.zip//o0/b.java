package o0;

// $FF: synthetic class
public final class b {
}
