package o0;

import android.view.View;

// $FF: synthetic class
public final class h implements i.b {
   // $FF: synthetic field
   public final Class[] a;

   // $FF: synthetic method
   public h(Class[] var1) {
      this.a = var1;
   }

   public final boolean a(View var1) {
      return i.b(this.a, var1);
   }
}
