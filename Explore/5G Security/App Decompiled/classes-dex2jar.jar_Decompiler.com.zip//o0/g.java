package o0;

import android.view.View;

// $FF: synthetic class
public final class g implements i.b {
   public final boolean a(View var1) {
      return i.a(var1);
   }
}
