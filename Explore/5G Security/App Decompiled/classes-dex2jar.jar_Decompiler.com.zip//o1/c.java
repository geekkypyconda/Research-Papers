package o1;

public final class c extends f {
   public static final o1.c m = new o1.c();

   private c() {
      super(o1.l.c, o1.l.d, o1.l.e, o1.l.a);
   }

   public void close() {
      throw new UnsupportedOperationException("Dispatchers.Default cannot be closed");
   }

   public String toString() {
      return "Dispatchers.Default";
   }
}
