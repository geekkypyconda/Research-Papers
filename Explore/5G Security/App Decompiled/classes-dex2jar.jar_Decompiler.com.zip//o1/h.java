package o1;

public abstract class h implements Runnable {
   public long e;
   public i f;

   public h() {
      this(0L, l.g);
   }

   public h(long var1, i var3) {
      this.e = var1;
      this.f = var3;
   }
}
