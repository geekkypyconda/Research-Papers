package o1;

final class j implements i {
   private final int a;

   public j(int var1) {
      this.a = var1;
   }

   public int a() {
      return this.a;
   }

   public void b() {
   }
}
