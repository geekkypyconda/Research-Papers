package o1;

public final class e extends g {
   public static final e a = new e();

   private e() {
   }

   public long a() {
      return System.nanoTime();
   }
}
