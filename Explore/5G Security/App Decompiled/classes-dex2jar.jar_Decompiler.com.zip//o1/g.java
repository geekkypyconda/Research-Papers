package o1;

public abstract class g {
   public abstract long a();
}
