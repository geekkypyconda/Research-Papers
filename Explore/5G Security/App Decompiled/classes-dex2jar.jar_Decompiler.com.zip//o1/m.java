package o1;

import h1.b0;
import m1.p;

final class m extends b0 {
   public static final m g = new m();

   private m() {
   }

   public void a(r0.g var1, Runnable var2) {
      o1.c.m.p(var2, l.h, false);
   }

   public b0 l(int var1) {
      p.a(var1);
      return (b0)(var1 >= l.d ? this : super.l(var1));
   }
}
