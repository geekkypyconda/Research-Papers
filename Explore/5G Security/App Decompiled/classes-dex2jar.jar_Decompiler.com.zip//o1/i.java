package o1;

public interface i {
   int a();

   void b();
}
