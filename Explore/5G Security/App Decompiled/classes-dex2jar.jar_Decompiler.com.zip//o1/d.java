package o1;

import m1.t;

public final class d extends t<h> {
   public d() {
      super(false);
   }
}
