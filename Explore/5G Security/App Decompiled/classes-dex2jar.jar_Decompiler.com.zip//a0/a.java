package a0;

import io.flutter.embedding.engine.FlutterJNI;
import j0.c;

public interface a {
   String a(int var1, String var2);

   void b();

   void c(c var1);

   void d(int var1, String var2);

   boolean e(int var1, String var2);

   void f(FlutterJNI var1);
}
