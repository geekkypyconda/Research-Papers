package z0;

public interface a<R> extends p0.c<R> {
   R b();
}
