package z0;

public interface p<P1, P2, R> extends p0.c<R> {
   R h(P1 var1, P2 var2);
}
