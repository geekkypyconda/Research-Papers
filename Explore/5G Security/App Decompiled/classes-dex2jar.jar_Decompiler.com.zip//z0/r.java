package z0;

public interface r<P1, P2, P3, P4, R> extends p0.c<R> {
}
