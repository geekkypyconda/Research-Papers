package z0;

public interface s<P1, P2, P3, P4, P5, R> extends p0.c<R> {
}
