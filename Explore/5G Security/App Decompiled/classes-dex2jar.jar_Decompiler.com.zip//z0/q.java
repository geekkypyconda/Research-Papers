package z0;

public interface q<P1, P2, P3, R> extends p0.c<R> {
   R g(P1 var1, P2 var2, P3 var3);
}
