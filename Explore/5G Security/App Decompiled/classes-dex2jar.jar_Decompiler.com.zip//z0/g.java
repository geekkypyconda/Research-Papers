package z0;

public interface g<P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, P11, P12, P13, P14, P15, R> extends p0.c<R> {
}
