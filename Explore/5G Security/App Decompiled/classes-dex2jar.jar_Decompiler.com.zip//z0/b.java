package z0;

public interface b<P1, P2, P3, P4, P5, P6, P7, P8, P9, P10, R> extends p0.c<R> {
}
