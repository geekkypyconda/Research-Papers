package z0;

public interface w<P1, P2, P3, P4, P5, P6, P7, P8, P9, R> extends p0.c<R> {
}
