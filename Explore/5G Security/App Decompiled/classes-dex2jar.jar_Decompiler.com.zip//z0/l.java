package z0;

public interface l<P1, R> extends p0.c<R> {
   R i(P1 var1);
}
