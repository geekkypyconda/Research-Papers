package com.example.my_app;

import io.flutter.embedding.android.f;

public final class MainActivity extends f {
}
