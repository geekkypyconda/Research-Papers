package h1;

public final class c {
   public static final b a() {
      return null;
   }
}
