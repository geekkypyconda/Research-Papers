package h1;

public final class x extends RuntimeException {
   public x(String var1, Throwable var2) {
      super(var1, var2);
   }
}
