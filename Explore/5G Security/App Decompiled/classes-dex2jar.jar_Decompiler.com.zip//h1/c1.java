package h1;

public final class c1 implements d1 {
   private final s1 e;

   public c1(s1 var1) {
      this.e = var1;
   }

   public boolean d() {
      return false;
   }

   public s1 f() {
      return this.e;
   }

   public String toString() {
      return super.toString();
   }
}
