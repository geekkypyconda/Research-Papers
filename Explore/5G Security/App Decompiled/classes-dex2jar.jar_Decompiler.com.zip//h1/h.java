package h1;

public abstract class h extends i implements u1 {
}
