package h1;

public interface u1 {
}
