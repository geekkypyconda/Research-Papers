package h1;

public interface d1 {
   boolean d();

   s1 f();
}
