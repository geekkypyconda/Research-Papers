package h1;

public final class w0 {
   public static final t0 a() {
      return new e(Thread.currentThread());
   }
}
