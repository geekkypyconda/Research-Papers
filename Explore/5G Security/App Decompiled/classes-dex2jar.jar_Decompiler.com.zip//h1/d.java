package h1;

final class d implements u1 {
   public static final d e = new d();

   private d() {
   }

   public String toString() {
      return "Active";
   }
}
