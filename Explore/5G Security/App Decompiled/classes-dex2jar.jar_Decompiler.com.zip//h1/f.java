package h1;

public final class f {
   public static final h1 a(e0 var0, r0.g var1, g0 var2, z0.p<? super e0, ? super r0.d<? super p0.q>, ? extends Object> var3) {
      return g.a(var0, var1, var2, var3);
   }

   // $FF: synthetic method
   public static h1 b(e0 var0, r0.g var1, g0 var2, z0.p var3, int var4, Object var5) {
      return g.b(var0, var1, var2, var3, var4, var5);
   }
}
