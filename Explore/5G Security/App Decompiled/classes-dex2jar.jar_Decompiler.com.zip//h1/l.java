package h1;

public final class l {
   public static final m1.h0 a = new m1.h0("RESUME_TOKEN");
}
