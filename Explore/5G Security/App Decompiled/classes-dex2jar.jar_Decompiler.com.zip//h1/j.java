package h1;

public interface j<T> extends r0.d<T> {
   void C(Object var1);

   Object l(T var1, Object var2, z0.l<? super Throwable, p0.q> var3);
}
