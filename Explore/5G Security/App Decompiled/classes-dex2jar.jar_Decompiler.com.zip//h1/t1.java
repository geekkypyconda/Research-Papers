package h1;

public final class t1 implements r0, p {
   public static final t1 e = new t1();

   private t1() {
   }

   public void a() {
   }

   public boolean c(Throwable var1) {
      return false;
   }

   public h1 getParent() {
      return null;
   }

   public String toString() {
      return "NonDisposableHandle";
   }
}
