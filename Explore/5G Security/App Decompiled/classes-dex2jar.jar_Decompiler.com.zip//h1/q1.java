package h1;

final class q1 extends w1 {
   private final r0.d<p0.q> h;

   public q1(r0.g var1, z0.p<? super e0, ? super r0.d<? super p0.q>, ? extends Object> var2) {
      super(var1, false);
      this.h = s0.b.a(var2, this, this);
   }

   protected void r0() {
      n1.a.b(this.h, this);
   }
}
