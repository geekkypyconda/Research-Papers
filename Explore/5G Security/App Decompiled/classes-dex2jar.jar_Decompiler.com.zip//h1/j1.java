package h1;

public abstract class j1 extends n1 {
}
