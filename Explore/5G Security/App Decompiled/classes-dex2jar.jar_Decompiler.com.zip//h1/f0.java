package h1;

public final class f0 {
   public static final e0 a(r0.g var0) {
      if (var0.b(h1.b) == null) {
         var0 = var0.n(l1.b((h1)null, 1, (Object)null));
      }

      return new m1.f(var0);
   }

   public static final <R> Object b(z0.p<? super e0, ? super r0.d<? super R>, ? extends Object> var0, r0.d<? super R> var1) {
      m1.d0 var2 = new m1.d0(var1.a(), var1);
      Object var3 = n1.b.b(var2, var2, var0);
      if (var3 == s0.b.c()) {
         t0.h.c(var1);
      }

      return var3;
   }
}
