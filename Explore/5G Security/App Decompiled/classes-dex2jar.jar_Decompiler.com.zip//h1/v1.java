package h1;

import java.util.concurrent.CancellationException;

public interface v1 extends h1 {
   CancellationException h();
}
