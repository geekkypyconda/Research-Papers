package h1;

final class b2 implements r0.g.b, r0.g.c<b2> {
   public static final b2 e = new b2();

   private b2() {
   }

   public <E extends r0.g.b> E b(r0.g.c<E> var1) {
      return r0.g.b.a.b(this, var1);
   }

   public r0.g.c<?> getKey() {
      return this;
   }

   public r0.g n(r0.g var1) {
      return r0.g.b.a.d(this, var1);
   }

   public r0.g x(r0.g.c<?> var1) {
      return r0.g.b.a.c(this, var1);
   }

   public <R> R y(R var1, z0.p<? super R, ? super r0.g.b, ? extends R> var2) {
      return r0.g.b.a.a(this, var1, var2);
   }
}
