package h1;

public final class q0 {
   public static final q0 a = new q0();
   private static final b0 b;
   private static final b0 c;
   private static final b0 d;

   static {
      b = o1.c.m;
      c = z1.g;
      d = o1.b.h;
   }

   private q0() {
   }

   public static final b0 a() {
      return b;
   }

   public static final b0 b() {
      return d;
   }

   public static final r1 c() {
      return m1.w.c;
   }
}
