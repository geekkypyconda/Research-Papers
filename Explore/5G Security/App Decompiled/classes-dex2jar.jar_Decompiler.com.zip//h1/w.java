package h1;

public abstract class w extends m1.s implements z0.l<Throwable, p0.q> {
   public abstract void x(Throwable var1);
}
