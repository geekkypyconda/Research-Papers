package h1;

public final class o extends j1 {
   public final k<?> i;

   public o(k<?> var1) {
      this.i = var1;
   }

   public void x(Throwable var1) {
      k var2 = this.i;
      var2.H(var2.t(this.y()));
   }
}
