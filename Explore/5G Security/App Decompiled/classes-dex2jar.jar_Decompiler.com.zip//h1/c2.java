package h1;

public interface c2 {
   void d(m1.e0<?> var1, int var2);
}
