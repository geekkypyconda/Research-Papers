package h1;

public abstract class i implements z0.l<Throwable, p0.q> {
   public abstract void f(Throwable var1);
}
