package h1;

import java.util.concurrent.CancellationException;

public final class l1 {
   public static final s a(h1 var0) {
      return m1.a(var0);
   }

   // $FF: synthetic method
   public static s b(h1 var0, int var1, Object var2) {
      return m1.b(var0, var1, var2);
   }

   public static final void c(r0.g var0, CancellationException var1) {
      m1.c(var0, var1);
   }

   public static final void d(h1 var0) {
      m1.d(var0);
   }

   public static final void e(r0.g var0) {
      m1.e(var0);
   }
}
