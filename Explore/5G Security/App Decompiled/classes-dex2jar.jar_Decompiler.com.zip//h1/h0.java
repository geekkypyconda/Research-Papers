package h1;

public final class h0 extends Error {
   public h0(String var1, Throwable var2) {
      super(var1, var2);
   }
}
