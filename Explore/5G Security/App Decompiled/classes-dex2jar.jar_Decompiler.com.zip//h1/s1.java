package h1;

public final class s1 extends m1.q implements d1 {
   public boolean d() {
      return true;
   }

   public s1 f() {
      return this;
   }

   public String toString() {
      return super.toString();
   }
}
