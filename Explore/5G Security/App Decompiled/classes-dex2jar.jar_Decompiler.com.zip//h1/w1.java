package h1;

class w1 extends h1.a<p0.q> {
   public w1(r0.g var1, boolean var2) {
      super(var1, true, var2);
   }

   protected boolean b0(Throwable var1) {
      d0.a(this.a(), var1);
      return true;
   }
}
