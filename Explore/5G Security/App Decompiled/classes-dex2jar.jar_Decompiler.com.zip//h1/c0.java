package h1;

public interface c0 extends r0.g.b {
   c0.a a = c0.a.e;

   void f(r0.g var1, Throwable var2);

   public static final class a implements r0.g.c<c0> {
      // $FF: synthetic field
      static final c0.a e = new c0.a();

      private a() {
      }
   }
}
