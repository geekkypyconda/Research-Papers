package h1;

public interface r0 {
   void a();
}
