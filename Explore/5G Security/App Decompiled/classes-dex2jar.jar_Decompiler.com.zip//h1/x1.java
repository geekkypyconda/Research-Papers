package h1;

public interface x1<S> extends r0.g.b {
   S B(r0.g var1);

   void g(r0.g var1, S var2);
}
