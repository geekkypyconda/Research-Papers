package h1;

public final class x0 {
   private static final m1.h0 a = new m1.h0("REMOVED_TASK");
   private static final m1.h0 b = new m1.h0("CLOSED_EMPTY");

   // $FF: synthetic method
   public static final m1.h0 a() {
      return b;
   }

   // $FF: synthetic method
   public static final m1.h0 b() {
      return a;
   }
}
