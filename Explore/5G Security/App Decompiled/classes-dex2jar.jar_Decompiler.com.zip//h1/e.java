package h1;

public final class e extends u0 {
   private final Thread m;

   public e(Thread var1) {
      this.m = var1;
   }

   protected Thread E() {
      return this.m;
   }
}
