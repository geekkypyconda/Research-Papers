package h1;

public interface s extends h1 {
}
