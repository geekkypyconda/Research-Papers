package h1;

public interface z<S> extends x1<S> {
   r0.g s(r0.g.b var1);

   z<S> t();
}
