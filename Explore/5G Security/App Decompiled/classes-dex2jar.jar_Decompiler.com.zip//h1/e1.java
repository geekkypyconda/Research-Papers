package h1;

final class e1 {
   public final d1 a;

   public e1(d1 var1) {
      this.a = var1;
   }
}
