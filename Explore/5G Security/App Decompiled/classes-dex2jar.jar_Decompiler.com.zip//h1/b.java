package h1;

public abstract class b {
}
