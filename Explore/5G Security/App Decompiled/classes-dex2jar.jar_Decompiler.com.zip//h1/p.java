package h1;

public interface p extends r0 {
   boolean c(Throwable var1);

   h1 getParent();
}
