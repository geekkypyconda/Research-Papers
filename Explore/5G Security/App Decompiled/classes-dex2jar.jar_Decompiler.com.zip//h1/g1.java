package h1;

final class g1 extends n1 {
   private final z0.l<Throwable, p0.q> i;

   public g1(z0.l<? super Throwable, p0.q> var1) {
      this.i = var1;
   }

   public void x(Throwable var1) {
      this.i.i(var1);
   }
}
