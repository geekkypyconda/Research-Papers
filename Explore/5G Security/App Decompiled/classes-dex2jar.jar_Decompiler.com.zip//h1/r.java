package h1;

public interface r extends h1 {
   void m(v1 var1);
}
