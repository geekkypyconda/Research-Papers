package h1;

public final class d2 extends r0.a {
   public static final d2.a g = new d2.a((a1.g)null);
   public boolean f;

   public d2() {
      super(g);
   }

   public static final class a implements r0.g.c<d2> {
      private a() {
      }

      // $FF: synthetic method
      public a(a1.g var1) {
         this();
      }
   }
}
