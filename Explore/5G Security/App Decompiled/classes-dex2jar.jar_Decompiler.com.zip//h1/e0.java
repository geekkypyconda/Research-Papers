package h1;

public interface e0 {
   r0.g r();
}
