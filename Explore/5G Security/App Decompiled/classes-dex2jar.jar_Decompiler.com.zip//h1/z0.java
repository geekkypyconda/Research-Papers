package h1;

import java.io.Closeable;

public abstract class z0 extends b0 implements Closeable {
   public static final z0.a g = new z0.a((a1.g)null);

   public static final class a extends r0.b<b0, z0> {
      private a() {
         super(b0.f, null.f);
      }

      // $FF: synthetic method
      public a(a1.g var1) {
         this();
      }
   }
}
