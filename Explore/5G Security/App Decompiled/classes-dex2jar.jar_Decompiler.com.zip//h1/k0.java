package h1;

public final class k0 {
   private static final boolean a = m1.i0.f("kotlinx.coroutines.main.delay", false);
   private static final l0 b = b();

   public static final l0 a() {
      return b;
   }

   private static final l0 b() {
      if (!a) {
         return j0.m;
      } else {
         r1 var0 = q0.c();
         Object var1;
         if (!m1.x.c(var0) && var0 instanceof l0) {
            var1 = (l0)var0;
         } else {
            var1 = j0.m;
         }

         return (l0)var1;
      }
   }
}
