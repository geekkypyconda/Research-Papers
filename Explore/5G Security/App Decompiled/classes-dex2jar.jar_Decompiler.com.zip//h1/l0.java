package h1;

public interface l0 {
}
