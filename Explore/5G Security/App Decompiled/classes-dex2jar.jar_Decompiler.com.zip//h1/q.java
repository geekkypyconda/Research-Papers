package h1;

public final class q extends j1 implements p {
   public final r i;

   public q(r var1) {
      this.i = var1;
   }

   public boolean c(Throwable var1) {
      return this.y().O(var1);
   }

   public h1 getParent() {
      return this.y();
   }

   public void x(Throwable var1) {
      this.i.m(this.y());
   }
}
