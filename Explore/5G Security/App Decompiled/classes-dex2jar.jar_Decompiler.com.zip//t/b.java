package t;

// $FF: synthetic class
public final class b implements Runnable {
   // $FF: synthetic field
   public final h.a e;

   // $FF: synthetic method
   public b(h.a var1) {
      this.e = var1;
   }

   public final void run() {
      c.c(this.e);
   }
}
