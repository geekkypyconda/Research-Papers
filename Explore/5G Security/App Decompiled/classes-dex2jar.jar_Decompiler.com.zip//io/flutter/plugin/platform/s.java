package io.flutter.plugin.platform;

// $FF: synthetic class
public final class s implements Runnable {
   // $FF: synthetic field
   public final w e;

   // $FF: synthetic method
   public s(w var1) {
      this.e = var1;
   }

   public final void run() {
      w.e(this.e);
   }
}
