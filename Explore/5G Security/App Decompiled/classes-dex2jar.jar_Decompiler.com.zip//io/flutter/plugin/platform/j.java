package io.flutter.plugin.platform;

import android.content.Context;

public abstract class j {
   private final k0.g<Object> a;

   public abstract i a(Context var1, int var2, Object var3);

   public final k0.g<Object> b() {
      return this.a;
   }
}
