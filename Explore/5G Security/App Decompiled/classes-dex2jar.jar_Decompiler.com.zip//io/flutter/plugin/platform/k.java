package io.flutter.plugin.platform;

public interface k {
}
