package io.flutter.plugin.platform;

import android.view.WindowManager;

final class h0 extends c0 {
   h0(WindowManager var1, x var2) {
      super(var1, var2);
   }
}
