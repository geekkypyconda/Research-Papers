package io.flutter.plugin.platform;

// $FF: synthetic class
public final class v implements Runnable {
   // $FF: synthetic field
   public final <undefinedtype> e;
   // $FF: synthetic field
   public final g0 f;
   // $FF: synthetic field
   public final float g;
   // $FF: synthetic field
   public final j0.m.b h;

   // $FF: synthetic method
   public v(Object var1, g0 var2, float var3, j0.m.b var4) {
      this.e = var1;
      this.f = var2;
      this.g = var3;
      this.h = var4;
   }

   public final void run() {
      null.j(this.e, this.f, this.g, this.h);
   }
}
