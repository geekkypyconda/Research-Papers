package io.flutter.plugin.platform;

import java.util.HashMap;
import java.util.Map;

class l implements k {
   private final Map<String, j> a = new HashMap();

   j a(String var1) {
      return (j)this.a.get(var1);
   }
}
