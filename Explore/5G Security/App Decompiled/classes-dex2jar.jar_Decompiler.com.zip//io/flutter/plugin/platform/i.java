package io.flutter.plugin.platform;

import android.view.View;

public interface i {
   void a();

   void b(View var1);

   void c();

   void d();

   void e();

   View f();
}
