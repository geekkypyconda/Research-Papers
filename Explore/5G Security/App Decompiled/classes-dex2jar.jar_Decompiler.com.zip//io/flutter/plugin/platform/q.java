package io.flutter.plugin.platform;

import android.view.View;

public interface q {
   void a();

   void b(io.flutter.view.h var1);

   boolean c(int var1);

   View d(int var1);
}
