package io.flutter.plugin.platform;

// $FF: synthetic class
public final class h implements Runnable {
   // $FF: synthetic field
   public final <undefinedtype> e;
   // $FF: synthetic field
   public final int f;

   // $FF: synthetic method
   public h(Object var1, int var2) {
      this.e = var1;
      this.f = var2;
   }

   public final void run() {
      null.a(this.e, this.f);
   }
}
