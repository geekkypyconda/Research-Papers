package io.flutter.plugin.platform;

// $FF: synthetic class
public final class z {
}
