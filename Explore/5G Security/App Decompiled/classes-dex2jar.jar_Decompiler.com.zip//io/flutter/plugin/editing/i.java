package io.flutter.plugin.editing;

// $FF: synthetic class
public final class i {
}
