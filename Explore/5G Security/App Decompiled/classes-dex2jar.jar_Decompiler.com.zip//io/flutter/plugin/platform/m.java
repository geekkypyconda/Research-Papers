package io.flutter.plugin.platform;

// $FF: synthetic class
public final class m {
   public static void a(n var0) {
   }
}
