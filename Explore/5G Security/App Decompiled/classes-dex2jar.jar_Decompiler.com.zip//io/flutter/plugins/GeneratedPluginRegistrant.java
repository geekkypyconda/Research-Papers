package io.flutter.plugins;

import io.flutter.embedding.engine.a;

public final class GeneratedPluginRegistrant {
   private static final String TAG = "GeneratedPluginRegistrant";

   public static void registerWith(a var0) {
   }
}
