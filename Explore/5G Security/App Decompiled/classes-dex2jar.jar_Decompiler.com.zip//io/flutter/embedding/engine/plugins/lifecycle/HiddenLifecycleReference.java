package io.flutter.embedding.engine.plugins.lifecycle;

import androidx.lifecycle.h;

public class HiddenLifecycleReference {
   private final h lifecycle;

   public HiddenLifecycleReference(h var1) {
      this.lifecycle = var1;
   }

   public h getLifecycle() {
      return this.lifecycle;
   }
}
