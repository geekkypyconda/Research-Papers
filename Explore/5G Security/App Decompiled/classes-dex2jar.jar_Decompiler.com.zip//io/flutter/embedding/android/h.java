package io.flutter.embedding.android;

public enum h {
   e,
   f;

   // $FF: synthetic method
   private static h[] a() {
      return new h[]{e, f};
   }
}
