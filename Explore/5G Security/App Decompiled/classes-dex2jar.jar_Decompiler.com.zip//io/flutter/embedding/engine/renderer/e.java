package io.flutter.embedding.engine.renderer;

public interface e {
   void a(FlutterRenderer var1);

   void b();

   void c();

   void d();

   FlutterRenderer getAttachedRenderer();
}
