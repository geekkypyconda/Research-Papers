package io.flutter.embedding.android;

import java.nio.ByteBuffer;

// $FF: synthetic class
public final class x implements k0.b.b {
   // $FF: synthetic field
   public final b0.d.a a;

   // $FF: synthetic method
   public x(b0.d.a var1) {
      this.a = var1;
   }

   public final void a(ByteBuffer var1) {
      a0.c(this.a, var1);
   }
}
