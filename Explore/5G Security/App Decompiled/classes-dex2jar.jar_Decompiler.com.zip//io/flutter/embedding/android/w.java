package io.flutter.embedding.android;

import java.nio.ByteBuffer;

public class w {
   long a;
   w.b b;
   long c;
   long d;
   boolean e;
   w.a f;
   String g;

   ByteBuffer a() {
      // $FF: Couldn't be decompiled
   }

   public static enum a {
      f(0L),
      g(1L),
      h(2L),
      i(3L),
      j(4L);

      private final long e;

      private a(long var3) {
         this.e = var3;
      }

      // $FF: synthetic method
      private static w.a[] a() {
         return new w.a[]{f, g, h, i, j};
      }

      public long b() {
         return this.e;
      }
   }

   public static enum b {
      f(0L),
      g(1L),
      h(2L);

      private long e;

      private b(long var3) {
         this.e = var3;
      }

      // $FF: synthetic method
      private static w.b[] a() {
         return new w.b[]{f, g, h};
      }

      public long b() {
         return this.e;
      }
   }
}
