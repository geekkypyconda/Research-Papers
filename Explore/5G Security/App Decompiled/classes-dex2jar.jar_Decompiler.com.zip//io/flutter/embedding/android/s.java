package io.flutter.embedding.android;

import android.view.textservice.SpellCheckerInfo;
import java.util.function.Predicate;

// $FF: synthetic class
public final class s implements Predicate {
   public final boolean test(Object var1) {
      return t.d((SpellCheckerInfo)var1);
   }
}
