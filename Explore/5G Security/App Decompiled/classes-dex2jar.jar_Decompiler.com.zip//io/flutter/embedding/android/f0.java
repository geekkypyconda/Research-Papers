package io.flutter.embedding.android;

public enum f0 {
   e,
   f;

   // $FF: synthetic method
   private static f0[] a() {
      return new f0[]{e, f};
   }
}
