package io.flutter.embedding.android;

// $FF: synthetic class
public final class u implements j0.e.a {
   // $FF: synthetic field
   public final b0.d.a a;

   // $FF: synthetic method
   public u(b0.d.a var1) {
      this.a = var1;
   }

   public final void a(boolean var1) {
      v.b(this.a, var1);
   }
}
