package io.flutter.embedding.android;

import android.app.Activity;
import java.util.concurrent.Executor;

public class g0 {
   final q.a a;

   public g0(q.a var1) {
      this.a = var1;
   }

   public void a(Activity var1, Executor var2, h.a<r.j> var3) {
      this.a.b(var1, var2, var3);
   }

   public void b(h.a<r.j> var1) {
      this.a.c(var1);
   }
}
