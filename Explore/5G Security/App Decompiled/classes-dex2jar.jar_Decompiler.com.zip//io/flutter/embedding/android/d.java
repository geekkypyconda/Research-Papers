package io.flutter.embedding.android;

public interface d<T> {
   void f();

   T g();
}
