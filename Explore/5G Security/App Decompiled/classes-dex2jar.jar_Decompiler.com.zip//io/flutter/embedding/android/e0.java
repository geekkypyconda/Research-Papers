package io.flutter.embedding.android;

public enum e0 {
   e,
   f,
   g;

   // $FF: synthetic method
   private static e0[] a() {
      return new e0[]{e, f, g};
   }
}
