package io.flutter.embedding.engine.renderer;

// $FF: synthetic class
public final class b implements Runnable {
   // $FF: synthetic field
   public final FlutterRenderer.f e;

   // $FF: synthetic method
   public b(FlutterRenderer.f var1) {
      this.e = var1;
   }

   public final void run() {
      FlutterRenderer.f.b(this.e);
   }
}
