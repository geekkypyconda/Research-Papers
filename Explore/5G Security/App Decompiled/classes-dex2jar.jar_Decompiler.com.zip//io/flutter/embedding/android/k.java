package io.flutter.embedding.android;

// $FF: synthetic class
public final class k {
}
