package io.flutter.view;

// $FF: synthetic class
public final class f implements o0.e {
   // $FF: synthetic field
   public final h.l a;

   // $FF: synthetic method
   public f(h.l var1) {
      this.a = var1;
   }

   public final boolean test(Object var1) {
      return h.b(this.a, (h.l)var1);
   }
}
