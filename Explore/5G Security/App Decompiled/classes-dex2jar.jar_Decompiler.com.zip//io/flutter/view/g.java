package io.flutter.view;

// $FF: synthetic class
public final class g implements o0.e {
   public final boolean test(Object var1) {
      return h.a((h.l)var1);
   }
}
