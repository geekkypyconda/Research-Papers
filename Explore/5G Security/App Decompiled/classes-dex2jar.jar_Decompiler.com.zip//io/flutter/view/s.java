package io.flutter.view;

// $FF: synthetic class
public final class s {
   public static void a(TextureRegistry.SurfaceTextureEntry var0, TextureRegistry.a var1) {
   }

   public static void b(TextureRegistry.SurfaceTextureEntry var0, TextureRegistry.b var1) {
   }
}
