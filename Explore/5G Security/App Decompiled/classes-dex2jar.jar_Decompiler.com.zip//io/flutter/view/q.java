package io.flutter.view;

// $FF: synthetic class
public final class q {
}
