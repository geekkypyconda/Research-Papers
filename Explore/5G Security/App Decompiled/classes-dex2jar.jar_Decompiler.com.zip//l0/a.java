package l0;

// $FF: synthetic class
public final class a {
}
