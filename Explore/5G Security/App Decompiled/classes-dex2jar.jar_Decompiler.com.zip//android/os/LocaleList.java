package android.os;

import java.util.Locale;

// $FF: synthetic class
public final class LocaleList implements Parcelable {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   public native Locale get(int var1);

   // $FF: synthetic method
   public native int size();
}
