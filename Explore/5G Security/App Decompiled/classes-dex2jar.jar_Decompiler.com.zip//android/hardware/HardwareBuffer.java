package android.hardware;

import android.os.Parcelable;

// $FF: synthetic class
public final class HardwareBuffer implements Parcelable, AutoCloseable {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   public native void close();
}
