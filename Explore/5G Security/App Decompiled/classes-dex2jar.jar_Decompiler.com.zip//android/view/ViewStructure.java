package android.view;

// $FF: synthetic class
public class ViewStructure {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   public abstract int addChildCount(int var1);

   // $FF: synthetic method
   public abstract ViewStructure newChild(int var1);

   // $FF: synthetic method
   public abstract void setDimens(int var1, int var2, int var3, int var4, int var5, int var6);

   // $FF: synthetic method
   public abstract void setHint(CharSequence var1);

   // $FF: synthetic method
   public abstract void setVisibility(int var1);
}
