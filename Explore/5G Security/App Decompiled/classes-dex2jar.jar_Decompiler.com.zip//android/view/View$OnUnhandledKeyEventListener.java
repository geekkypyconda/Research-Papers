package android.view;

// $FF: synthetic class
public interface View$OnUnhandledKeyEventListener {
   static {
      throw new NoClassDefFoundError();
   }
}
