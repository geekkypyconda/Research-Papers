package android.view;

// $FF: synthetic class
public class WindowInsetsAnimation$Callback {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   public WindowInsetsAnimation$Callback(int var1) {
   }
}
