package android.view;

// $FF: synthetic class
public final class WindowInsets$Type {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   public static native int captionBar();

   // $FF: synthetic method
   public static native int displayCutout();

   // $FF: synthetic method
   public static native int ime();

   // $FF: synthetic method
   public static native int mandatorySystemGestures();

   // $FF: synthetic method
   public static native int navigationBars();

   // $FF: synthetic method
   public static native int statusBars();

   // $FF: synthetic method
   public static native int systemGestures();

   // $FF: synthetic method
   public static native int tappableElement();
}
