package android.view;

import android.annotation.NonNull;
import android.graphics.Insets;

// $FF: synthetic class
public final class WindowInsets$Builder {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   public WindowInsets$Builder() {
   }

   // $FF: synthetic method
   public WindowInsets$Builder(@NonNull WindowInsets var1) {
   }

   // $FF: synthetic method
   @NonNull
   public native WindowInsets build();

   // $FF: synthetic method
   @Deprecated
   @NonNull
   public native WindowInsets$Builder setMandatorySystemGestureInsets(@NonNull Insets var1);

   // $FF: synthetic method
   @Deprecated
   @NonNull
   public native WindowInsets$Builder setStableInsets(@NonNull Insets var1);

   // $FF: synthetic method
   @Deprecated
   @NonNull
   public native WindowInsets$Builder setSystemGestureInsets(@NonNull Insets var1);

   // $FF: synthetic method
   @Deprecated
   @NonNull
   public native WindowInsets$Builder setSystemWindowInsets(@NonNull Insets var1);

   // $FF: synthetic method
   @Deprecated
   @NonNull
   public native WindowInsets$Builder setTappableElementInsets(@NonNull Insets var1);
}
