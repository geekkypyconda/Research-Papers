package android.view;

// $FF: synthetic class
public final class WindowInsetsAnimation {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   public native int getTypeMask();
}
