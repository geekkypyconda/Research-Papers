package android.view;

// $FF: synthetic class
public interface WindowInsetsController {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   void setSystemBarsAppearance(int var1, int var2);
}
