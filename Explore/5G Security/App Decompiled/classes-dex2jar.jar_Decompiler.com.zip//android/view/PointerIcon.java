package android.view;

import android.annotation.NonNull;
import android.content.Context;
import android.os.Parcelable;

// $FF: synthetic class
public final class PointerIcon implements Parcelable {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   @NonNull
   public static native PointerIcon getSystemIcon(@NonNull Context var0, int var1);
}
