package android.view;

import android.annotation.NonNull;
import android.graphics.Rect;

// $FF: synthetic class
public final class WindowMetrics {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   @NonNull
   public native Rect getBounds();

   // $FF: synthetic method
   @NonNull
   public native WindowInsets getWindowInsets();
}
