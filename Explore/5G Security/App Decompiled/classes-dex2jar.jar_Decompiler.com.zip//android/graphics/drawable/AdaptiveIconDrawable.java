package android.graphics.drawable;

import android.graphics.drawable.Drawable.Callback;

// $FF: synthetic class
public class AdaptiveIconDrawable extends Drawable implements Callback {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   public AdaptiveIconDrawable(Drawable var1, Drawable var2) {
   }
}
