package android.graphics;

// $FF: synthetic class
public interface ImageDecoder$OnHeaderDecodedListener {
   static {
      throw new NoClassDefFoundError();
   }
}
