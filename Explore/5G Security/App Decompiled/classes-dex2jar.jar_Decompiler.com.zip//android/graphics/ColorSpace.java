package android.graphics;

import android.annotation.NonNull;

// $FF: synthetic class
public class ColorSpace {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   @NonNull
   public static native ColorSpace get(@NonNull ColorSpace$Named var0);
}
