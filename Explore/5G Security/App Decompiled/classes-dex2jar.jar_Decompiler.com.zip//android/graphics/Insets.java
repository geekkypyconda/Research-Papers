package android.graphics;

import android.annotation.NonNull;
import android.os.Parcelable;

// $FF: synthetic class
public final class Insets implements Parcelable {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   @NonNull
   public static native Insets of(int var0, int var1, int var2, int var3);
}
