package android.graphics;

import android.annotation.NonNull;
import android.util.Size;

// $FF: synthetic class
public class ImageDecoder$ImageInfo {
   static {
      throw new NoClassDefFoundError();
   }

   // $FF: synthetic method
   @NonNull
   public native Size getSize();
}
