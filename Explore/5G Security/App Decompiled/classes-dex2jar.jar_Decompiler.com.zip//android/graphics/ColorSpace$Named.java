package android.graphics;

// $FF: synthetic class
public final class ColorSpace$Named extends Enum {
   static {
      throw new NoClassDefFoundError();
   }
}
