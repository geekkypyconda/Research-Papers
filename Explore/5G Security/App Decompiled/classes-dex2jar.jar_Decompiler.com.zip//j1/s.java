package j1;

import h1.c2;
import m1.e0;

final class s<E> implements c2 {
   public final h1.k<h<? extends E>> e;

   public void d(e0<?> var1, int var2) {
      this.e.d(var1, var2);
   }
}
