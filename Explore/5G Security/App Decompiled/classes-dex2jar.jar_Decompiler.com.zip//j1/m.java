package j1;

import java.util.NoSuchElementException;

public final class m extends NoSuchElementException {
   public m(String var1) {
      super(var1);
   }
}
