package j1;

public interface f<E> {
   Object a(r0.d<? super Boolean> var1);

   E next();
}
