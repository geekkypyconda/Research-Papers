package j1;

public enum a {
   e,
   f,
   g;

   // $FF: synthetic method
   private static final a[] a() {
      return new a[]{e, f, g};
   }
}
