package j1;

public final class k {
   public static final void a(t<?> var0, Throwable var1) {
      l.a(var0, var1);
   }
}
