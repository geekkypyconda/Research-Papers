package j1;

public final class n extends IllegalStateException {
   public n(String var1) {
      super(var1);
   }
}
