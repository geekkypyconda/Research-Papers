package j1;

import h1.d0;

final class q<E> extends e<E> implements r<E> {
   public q(r0.g var1, d<E> var2) {
      super(var1, var2, true, true);
   }

   protected void H0(Throwable var1, boolean var2) {
      if (!this.K0().p(var1) && !var2) {
         d0.a(this.a(), var1);
      }

   }

   protected void L0(p0.q var1) {
      u.a.a(this.K0(), (Throwable)null, 1, (Object)null);
   }

   public boolean d() {
      return super.d();
   }
}
