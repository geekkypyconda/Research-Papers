package j1;

import java.util.concurrent.CancellationException;

public interface t<E> {
   void c(CancellationException var1);

   f<E> iterator();
}
