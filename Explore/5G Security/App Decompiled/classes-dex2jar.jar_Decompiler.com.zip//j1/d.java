package j1;

import m1.i0;

public interface d<E> extends u<E>, t<E> {
   d.a c = d.a.a;

   public static final class a {
      // $FF: synthetic field
      static final d.a a = new d.a();
      private static final int b = i0.b("kotlinx.coroutines.channels.defaultBuffer", 64, 1, 2147483646);

      private a() {
      }

      public final int a() {
         return b;
      }
   }
}
