package j1;

import h1.e0;

public interface r<E> extends e0, u<E> {
}
