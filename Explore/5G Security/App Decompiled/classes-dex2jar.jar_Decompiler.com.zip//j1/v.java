package j1;

import h1.c2;

final class v {
   public final c2 a;

   public v(c2 var1) {
      this.a = var1;
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder();
      var1.append("WaiterEB(");
      var1.append(this.a);
      var1.append(')');
      return var1.toString();
   }
}
